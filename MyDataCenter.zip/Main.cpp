
#include <iostream.h>
#include <string>

using namespace std;

#include "LmDataCenter.h"

int main()
{
	LmDataCenter dataCenter;

	dataCenter.Run();
	
}